# Authentication Security Note

## Scope
This repository implements a small local authentication service for an authorized defensive lab. It is intended for learning and automated verification, not public deployment.

## Threats and controls
| Threat | Control | Verification |
|---|---|---|
| Plaintext password disclosure | Werkzeug `scrypt` password hashing | Registration/login test; inspect database only in a disposable lab and confirm stored value is a hash |
| Malformed input | Server-side username/password validation and request-size cap | Invalid username and short-password tests |
| Username enumeration | Same generic login error for unknown user and incorrect password | Generic-error test |
| Brute-force attempts | Per-IP + username in-memory rate limit | Rate-limit test expects HTTP 429 |
| Session theft via script | HttpOnly cookie | Cookie-flags test |
| Cross-site cookie sending | SameSite=Lax | Cookie-flags test |
| Stale authenticated session | 15-minute permanent-session lifetime and logout | Logout test; expiry setting review |

## Safe operating notes
- Keep the service bound to `127.0.0.1` during the lab.
- Replace `AUTH_SECRET_KEY` with a cryptographically random secret.
- Enable `AUTH_COOKIE_SECURE=1` when running behind HTTPS.
- Never commit `.env`, real credentials, database files, or session cookies.
- Use only synthetic test accounts and data.

## Known gaps / next steps
The in-memory rate limiter is suitable only for a single-process demo and can be bypassed by restarting the app. It is not a substitute for a shared production limiter. The app does not implement CSRF tokens, email verification, password reset, MFA, audit-log retention, or production deployment hardening. Add these before any real-world use.
