import os
import sqlite3
import time
from collections import defaultdict, deque
from pathlib import Path
from functools import wraps

from flask import Flask, g, jsonify, request, session
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE = os.environ.get("AUTH_DB_PATH", str(BASE_DIR / "auth.db"))

def create_app(test_config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("AUTH_SECRET_KEY", "dev-only-change-this-secret"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("AUTH_COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=900,  # 15 minutes
        MAX_CONTENT_LENGTH=16 * 1024,
        RATE_LIMIT_MAX=5,
        RATE_LIMIT_WINDOW=60,
        DATABASE=DATABASE,
        TESTING=False,
    )
    if test_config:
        app.config.update(test_config)

    # Small in-memory limiter for a local demo. Production systems should use
    # a shared store (for example Redis) and a trusted proxy configuration.
    attempts = defaultdict(deque)

    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def close_db(_error=None):
        connection = g.pop("db", None)
        if connection is not None:
            connection.close()

    def init_db():
        with app.app_context():
            db().execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL
                )
            """)
            db().commit()

    def limited(key):
        now = time.time()
        queue = attempts[key]
        window = app.config["RATE_LIMIT_WINDOW"]
        while queue and queue[0] <= now - window:
            queue.popleft()
        if len(queue) >= app.config["RATE_LIMIT_MAX"]:
            return True
        queue.append(now)
        return False

    def valid_username(username):
        return (
            isinstance(username, str)
            and 3 <= len(username) <= 32
            and username.isascii()
            and all(ch.isalnum() or ch in "_-" for ch in username)
        )

    def valid_password(password):
        return isinstance(password, str) and 12 <= len(password) <= 128

    def json_body():
        body = request.get_json(silent=True)
        return body if isinstance(body, dict) else {}

    @app.get("/health")
    def health():
        return jsonify(status="ok")

    @app.post("/register")
    def register():
        body = json_body()
        username = body.get("username")
        password = body.get("password")

        if not valid_username(username):
            return jsonify(error="Invalid username or password format."), 400
        if not valid_password(password):
            return jsonify(error="Invalid username or password format."), 400

        password_hash = generate_password_hash(password, method="scrypt")
        try:
            db().execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, password_hash),
            )
            db().commit()
        except sqlite3.IntegrityError:
            # Avoid exposing whether a username is already registered.
            return jsonify(error="Unable to create account with those details."), 409

        return jsonify(message="Account created."), 201

    @app.post("/login")
    def login():
        body = json_body()
        username = body.get("username")
        password = body.get("password")
        ip = request.remote_addr or "unknown"
        normalized_username = username if isinstance(username, str) else "invalid"
        key = f"{ip}:{normalized_username.lower()}"

        if limited(key):
            return jsonify(error="Too many attempts. Try again later."), 429

        # Same response for unknown username and wrong password.
        user = None
        if isinstance(username, str) and isinstance(password, str):
            user = db().execute(
                "SELECT id, username, password_hash FROM users WHERE username = ?",
                (username,),
            ).fetchone()

        # Perform a hash check even for unknown users to reduce timing differences.
        if user is None:
            check_password_hash(
                generate_password_hash("not-the-user-password", method="scrypt"),
                password if isinstance(password, str) else "",
            )
            return jsonify(error="Invalid username or password."), 401

        if not check_password_hash(user["password_hash"], password):
            return jsonify(error="Invalid username or password."), 401

        session.clear()
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        session.permanent = True
        return jsonify(message="Login successful.", username=user["username"]), 200

    @app.get("/me")
    def me():
        user_id = session.get("user_id")
        if not user_id:
            return jsonify(error="Authentication required."), 401
        user = db().execute(
            "SELECT id, username FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if user is None:
            session.clear()
            return jsonify(error="Authentication required."), 401
        return jsonify(id=user["id"], username=user["username"]), 200

    @app.post("/logout")
    def logout():
        session.clear()
        return jsonify(message="Logged out."), 200

    init_db()
    return app

app = create_app()

if __name__ == "__main__":
    # Local-only by default. Do not expose this development server to the internet.
    app.run(host="127.0.0.1", port=5000, debug=False)
