import os
import tempfile
import pytest
from app import create_app

@pytest.fixture()
def client():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    app = create_app({
        "TESTING": True,
        "DATABASE": path,
        "SECRET_KEY": "test-secret-key",
        "RATE_LIMIT_MAX": 5,
        "RATE_LIMIT_WINDOW": 60,
        "SESSION_COOKIE_HTTPONLY": True,
        "SESSION_COOKIE_SAMESITE": "Lax",
        "SESSION_COOKIE_SECURE": False,
    })
    with app.test_client() as client:
        yield client
    os.unlink(path)

def register(client, username="student_1", password="CorrectHorseBattery!42"):
    return client.post("/register", json={"username": username, "password": password})

def test_register_and_login(client):
    response = register(client)
    assert response.status_code == 201
    response = client.post("/login", json={
        "username": "student_1", "password": "CorrectHorseBattery!42"
    })
    assert response.status_code == 200
    assert client.get("/me").status_code == 200

def test_rejects_short_password(client):
    response = register(client, password="short")
    assert response.status_code == 400

def test_rejects_invalid_username(client):
    response = register(client, username="bad user")
    assert response.status_code == 400

def test_generic_login_error_for_unknown_user_and_wrong_password(client):
    register(client)
    wrong_password = client.post("/login", json={
        "username": "student_1", "password": "wrong-password"
    })
    unknown_user = client.post("/login", json={
        "username": "no_such_user", "password": "wrong-password"
    })
    assert wrong_password.status_code == unknown_user.status_code == 401
    assert wrong_password.get_json()["error"] == unknown_user.get_json()["error"]

def test_rate_limit(client):
    register(client)
    statuses = []
    for _ in range(6):
        response = client.post("/login", json={
            "username": "student_1", "password": "wrong-password"
        })
        statuses.append(response.status_code)
    assert 429 in statuses

def test_logout_clears_session(client):
    register(client)
    client.post("/login", json={
        "username": "student_1", "password": "CorrectHorseBattery!42"
    })
    assert client.get("/me").status_code == 200
    assert client.post("/logout").status_code == 200
    assert client.get("/me").status_code == 401

def test_cookie_security_flags_configured(client):
    register(client)
    client.post("/login", json={
        "username": "student_1", "password": "CorrectHorseBattery!42"
    })
    cookie = client.get_cookie("session")
    assert cookie is not None
    assert cookie.http_only is True
    assert cookie.same_site == "Lax"
