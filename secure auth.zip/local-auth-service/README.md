# Local Authentication Service (Defensive Security Lab)

A beginner-friendly Flask authentication demo showing password hashing, server-side validation, generic login errors, rate limiting, session expiry, secure cookie flags, logout, and automated tests.

## Requirements
- Python 3.10+
- pip

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Set a secret key before starting. Example for macOS/Linux:
```bash
export AUTH_SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
python app.py
```
Windows PowerShell:
```powershell
$env:AUTH_SECRET_KEY = python -c "import secrets; print(secrets.token_hex(32))"
python app.py
```

The service listens only on `127.0.0.1:5000`.

## API examples
Register:
```bash
curl -i -X POST http://127.0.0.1:5000/register \
  -H "Content-Type: application/json" \
  -d '{"username":"student_1","password":"CorrectHorseBattery!42"}'
```

Login (save the session cookie):
```bash
curl -i -c cookies.txt -X POST http://127.0.0.1:5000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"student_1","password":"CorrectHorseBattery!42"}'
```

Current session:
```bash
curl -i -b cookies.txt http://127.0.0.1:5000/me
```

Logout:
```bash
curl -i -b cookies.txt -X POST http://127.0.0.1:5000/logout
```

## Run automated tests
```bash
pytest -v
```
Capture the real terminal output for your evidence. Do not claim tests passed unless you ran them.

## Security controls
- Passwords are stored as Werkzeug `scrypt` password hashes, not plaintext.
- Username and password lengths/formats are validated server-side.
- SQL queries use parameter placeholders.
- Login errors are generic for unknown users and wrong passwords.
- Login attempts are rate-limited by IP and username.
- Session cookies are HttpOnly and SameSite=Lax; Secure can be enabled for HTTPS.
- Sessions are permanent with a 15-minute configured lifetime; logout clears the session.

## Important limitations
This is a local educational demo, not a production-ready identity provider. The rate limiter is in-memory and resets when the process restarts; it is not shared across multiple workers. For production, use a shared rate-limit store, HTTPS, CSRF protection for browser-based state-changing requests, secure secret management, monitoring, account recovery controls, and a reviewed deployment configuration. The default secret is for development only; always override it.
